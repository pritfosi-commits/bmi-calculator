package com.example

import com.example.model.BmiCategory
import com.example.ui.BmiViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ExampleUnitTest {

    private lateinit var viewModel: BmiViewModel

    @Before
    fun setup() {
        viewModel = BmiViewModel()
    }

    @Test
    fun testNormalWeightCalculation() {
        viewModel.onWeightChange("70")
        viewModel.onHeightChange("175")
        viewModel.calculateBmi()

        val state = viewModel.uiState.value
        assertNotNull(state.result)
        val result = state.result!!
        assertEquals(BmiCategory.NORMAL, result.category)
        assertEquals(22.86, result.bmi, 0.1)
        assertNull(state.weightError)
        assertNull(state.heightError)
    }

    @Test
    fun testUnderweightCalculation() {
        viewModel.onWeightChange("45")
        viewModel.onHeightChange("170")
        viewModel.calculateBmi()

        val state = viewModel.uiState.value
        assertNotNull(state.result)
        val result = state.result!!
        assertEquals(BmiCategory.UNDERWEIGHT, result.category)
        assertTrue(result.bmi < 18.5)
    }

    @Test
    fun testOverweightCalculation() {
        viewModel.onWeightChange("85")
        viewModel.onHeightChange("175")
        viewModel.calculateBmi()

        val state = viewModel.uiState.value
        assertNotNull(state.result)
        val result = state.result!!
        assertEquals(BmiCategory.OVERWEIGHT, result.category)
        assertTrue(result.bmi in 25.0..29.99)
    }

    @Test
    fun testObeseCalculation() {
        viewModel.onWeightChange("110")
        viewModel.onHeightChange("170")
        viewModel.calculateBmi()

        val state = viewModel.uiState.value
        assertNotNull(state.result)
        val result = state.result!!
        assertEquals(BmiCategory.OBESE, result.category)
        assertTrue(result.bmi >= 30.0)
    }

    @Test
    fun testInvalidInputsHandling() {
        viewModel.onWeightChange("")
        viewModel.onHeightChange("")
        viewModel.calculateBmi()

        val state = viewModel.uiState.value
        assertNull(state.result)
        assertNotNull(state.weightError)
        assertNotNull(state.heightError)
    }

    @Test
    fun testResetFunctionality() {
        viewModel.onWeightChange("75")
        viewModel.onHeightChange("180")
        viewModel.calculateBmi()
        assertNotNull(viewModel.uiState.value.result)

        viewModel.reset()
        val resetState = viewModel.uiState.value
        assertEquals("", resetState.weightInput)
        assertEquals("", resetState.heightInput)
        assertNull(resetState.result)
    }
}
