package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Height
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BmiCategory
import com.example.model.BmiCalculationResult
import com.example.ui.theme.ColorNormalWeight
import com.example.ui.theme.ColorObese
import com.example.ui.theme.ColorOverweight
import com.example.ui.theme.ColorUnderweight
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BmiScreen(
    viewModel: BmiViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                },
                actions = {
                    if (uiState.weightInput.isNotEmpty() || uiState.heightInput.isNotEmpty() || uiState.result != null) {
                        IconButton(
                            onClick = {
                                viewModel.reset()
                                focusManager.clearFocus()
                            },
                            modifier = Modifier.testTag("app_bar_reset_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = stringResource(R.string.reset)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 560.dp)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .animateContentSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Input Card
                InputCard(
                    uiState = uiState,
                    onWeightChange = viewModel::onWeightChange,
                    onHeightChange = viewModel::onHeightChange,
                    onAdjustWeight = viewModel::adjustWeight,
                    onAdjustHeight = viewModel::adjustHeight,
                    onCalculate = {
                        focusManager.clearFocus()
                        viewModel.calculateBmi()
                    },
                    onClear = {
                        focusManager.clearFocus()
                        viewModel.reset()
                    }
                )

                // Calculation Result
                AnimatedVisibility(
                    visible = uiState.result != null,
                    enter = fadeIn() + slideInVertically(initialOffsetY = { 40 })
                ) {
                    uiState.result?.let { result ->
                        ResultCard(result = result)
                    }
                }

                // Reference Categories Guide Card
                ReferenceGuideCard(activeCategory = uiState.result?.category)

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun InputCard(
    uiState: BmiUiState,
    onWeightChange: (String) -> Unit,
    onHeightChange: (String) -> Unit,
    onAdjustWeight: (Double) -> Unit,
    onAdjustHeight: (Double) -> Unit,
    onCalculate: () -> Unit,
    onClear: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Enter Body Measurements",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold
                ),
                color = MaterialTheme.colorScheme.onSurface
            )

            // Weight Field
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = uiState.weightInput,
                    onValueChange = onWeightChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("weight_input"),
                    label = { Text(stringResource(R.string.weight_label) + " (" + stringResource(R.string.weight_unit) + ")") },
                    placeholder = { Text(stringResource(R.string.weight_placeholder)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.MonitorWeight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.weight_unit),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    isError = uiState.weightError != null,
                    supportingText = {
                        if (uiState.weightError != null) {
                            Text(
                                text = uiState.weightError,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Next
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                // Quick Weight adjustments
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickAdjustChip(text = "-1 kg", onClick = { onAdjustWeight(-1.0) })
                    QuickAdjustChip(text = "+1 kg", onClick = { onAdjustWeight(1.0) })
                    QuickAdjustChip(text = "-5 kg", onClick = { onAdjustWeight(-5.0) })
                    QuickAdjustChip(text = "+5 kg", onClick = { onAdjustWeight(5.0) })
                }
            }

            // Height Field
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    value = uiState.heightInput,
                    onValueChange = onHeightChange,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("height_input"),
                    label = { Text(stringResource(R.string.height_label) + " (" + stringResource(R.string.height_unit) + ")") },
                    placeholder = { Text(stringResource(R.string.height_placeholder)) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Height,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                    },
                    trailingIcon = {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.height_unit),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    isError = uiState.heightError != null,
                    supportingText = {
                        if (uiState.heightError != null) {
                            Text(
                                text = uiState.heightError,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = { onCalculate() }
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                // Quick Height adjustments
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickAdjustChip(text = "-1 cm", onClick = { onAdjustHeight(-1.0) })
                    QuickAdjustChip(text = "+1 cm", onClick = { onAdjustHeight(1.0) })
                    QuickAdjustChip(text = "-5 cm", onClick = { onAdjustHeight(-5.0) })
                    QuickAdjustChip(text = "+5 cm", onClick = { onAdjustHeight(5.0) })
                }
            }

            // General error if any
            if (uiState.generalError != null && uiState.weightError == null && uiState.heightError == null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = uiState.generalError,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onClear,
                    modifier = Modifier
                        .weight(0.35f)
                        .height(52.dp)
                        .testTag("clear_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(
                        text = stringResource(R.string.reset),
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Medium)
                    )
                }

                Button(
                    onClick = onCalculate,
                    modifier = Modifier
                        .weight(0.65f)
                        .height(52.dp)
                        .testTag("calculate_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Calculate,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.calculate_bmi),
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun QuickAdjustChip(
    text: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = Modifier.height(28.dp)
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ResultCard(
    result: BmiCalculationResult
) {
    val categoryColor = when (result.category) {
        BmiCategory.UNDERWEIGHT -> ColorUnderweight
        BmiCategory.NORMAL -> ColorNormalWeight
        BmiCategory.OVERWEIGHT -> ColorOverweight
        BmiCategory.OBESE -> ColorObese
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("result_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = categoryColor.copy(alpha = 0.08f)
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                colors = listOf(
                    categoryColor.copy(alpha = 0.4f),
                    categoryColor.copy(alpha = 0.15f)
                )
            )
        )
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.bmi_result_title),
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )

            // Large BMI Score Display
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = String.format(Locale.US, "%.1f", result.bmi),
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.ExtraBold
                    ),
                    color = categoryColor,
                    modifier = Modifier.testTag("bmi_score_text")
                )
                Text(
                    text = " kg/m²",
                    style = MaterialTheme.typography.titleSmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.padding(bottom = 8.dp, start = 4.dp)
                )
            }

            // Category Badge
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = categoryColor,
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("bmi_category_text"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val badgeIcon = when (result.category) {
                        BmiCategory.NORMAL -> Icons.Default.Check
                        BmiCategory.UNDERWEIGHT -> Icons.Default.Info
                        BmiCategory.OVERWEIGHT -> Icons.Default.Info
                        BmiCategory.OBESE -> Icons.Default.Warning
                    }
                    Icon(
                        imageVector = badgeIcon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = result.category.title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                }
            }

            // Visual Spectrum / Gauge Bar
            BmiSpectrumGauge(bmi = result.bmi)

            // Advice / Explanation
            Text(
                text = result.category.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            )

            // Healthy Weight Range Info
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "Healthy weight for your height",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${String.format(Locale.US, "%.1f", result.healthyWeightMinKg)} – ${String.format(Locale.US, "%.1f", result.healthyWeightMaxKg)} kg",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = CircleShape,
                    color = ColorNormalWeight.copy(alpha = 0.15f),
                    modifier = Modifier.size(32.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = ColorNormalWeight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BmiSpectrumGauge(bmi: Double) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Multi-segment gauge bar
        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
            val totalWidth = maxWidth

            // Gauge bar segments
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
            ) {
                // Underweight (< 18.5): weight ~ 18.5
                Box(
                    modifier = Modifier
                        .weight(18.5f)
                        .fillMaxSize()
                        .background(ColorUnderweight)
                )
                // Normal (18.5 - 24.9): weight ~ 6.5
                Box(
                    modifier = Modifier
                        .weight(6.5f)
                        .fillMaxSize()
                        .background(ColorNormalWeight)
                )
                // Overweight (25 - 29.9): weight ~ 5.0
                Box(
                    modifier = Modifier
                        .weight(5.0f)
                        .fillMaxSize()
                        .background(ColorOverweight)
                )
                // Obese (>= 30): weight ~ 10.0
                Box(
                    modifier = Modifier
                        .weight(10.0f)
                        .fillMaxSize()
                        .background(ColorObese)
                )
            }

            // Position calculation for needle marker:
            // Gauge covers BMI 14 to 40 (span: 26)
            val clampedBmi = bmi.coerceIn(14.0, 40.0)
            val fraction = ((clampedBmi - 14.0) / (40.0 - 14.0)).toFloat().coerceIn(0f, 1f)
            val offsetDp = (totalWidth * fraction) - 6.dp

            // Indicator Needle
            Box(
                modifier = Modifier
                    .offset(x = offsetDp, y = (-3).dp)
                    .size(16.dp)
                    .background(Color.White, shape = CircleShape)
                    .border(2.dp, MaterialTheme.colorScheme.onSurface, shape = CircleShape)
            )
        }

        // Labels underneath gauge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "< 18.5",
                style = MaterialTheme.typography.labelSmall,
                color = ColorUnderweight
            )
            Text(
                text = "18.5 – 24.9",
                style = MaterialTheme.typography.labelSmall,
                color = ColorNormalWeight
            )
            Text(
                text = "25.0 – 29.9",
                style = MaterialTheme.typography.labelSmall,
                color = ColorOverweight
            )
            Text(
                text = "≥ 30.0",
                style = MaterialTheme.typography.labelSmall,
                color = ColorObese
            )
        }
    }
}

@Composable
private fun ReferenceGuideCard(
    activeCategory: BmiCategory?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "BMI Categories (WHO Standard)",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.SemiBold
                ),
                color = MaterialTheme.colorScheme.onSurface
            )

            CategoryRow(
                title = "Underweight",
                range = "< 18.5",
                color = ColorUnderweight,
                isActive = activeCategory == BmiCategory.UNDERWEIGHT
            )

            CategoryRow(
                title = "Normal weight",
                range = "18.5 – 24.9",
                color = ColorNormalWeight,
                isActive = activeCategory == BmiCategory.NORMAL
            )

            CategoryRow(
                title = "Overweight",
                range = "25.0 – 29.9",
                color = ColorOverweight,
                isActive = activeCategory == BmiCategory.OVERWEIGHT
            )

            CategoryRow(
                title = "Obese",
                range = "≥ 30.0",
                color = ColorObese,
                isActive = activeCategory == BmiCategory.OBESE
            )
        }
    }
}

@Composable
private fun CategoryRow(
    title: String,
    range: String,
    color: Color,
    isActive: Boolean
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = if (isActive) color.copy(alpha = 0.15f) else Color.Transparent,
        border = if (isActive) CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(color, color))) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(color, shape = CircleShape)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = range,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
                    ),
                    color = if (isActive) color else MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (isActive) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Active",
                        tint = color,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
