package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF006A60)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFF73F8E5)
val TealOnPrimaryContainer = Color(0xFF00201C)

val TealSecondary = Color(0xFF4A635E)
val TealOnSecondary = Color(0xFFFFFFFF)
val TealSecondaryContainer = Color(0xFFCCE8E2)
val TealOnSecondaryContainer = Color(0xFF05201C)

val TealTertiary = Color(0xFF456179)
val TealOnTertiary = Color(0xFFFFFFFF)
val TealTertiaryContainer = Color(0xFFCCE5FF)
val TealOnTertiaryContainer = Color(0xFF001E31)

val BackgroundLight = Color(0xFFF4FBF8)
val OnBackgroundLight = Color(0xFF161D1B)
val SurfaceLight = Color(0xFFF4FBF8)
val OnSurfaceLight = Color(0xFF161D1B)
val SurfaceVariantLight = Color(0xFFDAE5E1)
val OnSurfaceVariantLight = Color(0xFF3F4946)

// Dark Theme Colors
val TealPrimaryDark = Color(0xFF53DBC9)
val TealOnPrimaryDark = Color(0xFF003731)
val TealPrimaryContainerDark = Color(0xFF005048)
val TealOnPrimaryContainerDark = Color(0xFF73F8E5)

val TealSecondaryDark = Color(0xFFB1CCC6)
val TealOnSecondaryDark = Color(0xFF1C3531)
val TealSecondaryContainerDark = Color(0xFF324B47)
val TealOnSecondaryContainerDark = Color(0xFFCCE8E2)

val BackgroundDark = Color(0xFF0E1514)
val OnBackgroundDark = Color(0xFFDEE4E1)
val SurfaceDark = Color(0xFF0E1514)
val OnSurfaceDark = Color(0xFFDEE4E1)
val SurfaceVariantDark = Color(0xFF3F4946)
val OnSurfaceVariantDark = Color(0xFFBFC9C5)

// Category Accent Colors
val ColorUnderweight = Color(0xFF0284C7) // Sky blue
val ColorNormalWeight = Color(0xFF16A34A) // Emerald green
val ColorOverweight = Color(0xFFF59E0B) // Amber
val ColorObese = Color(0xFFEF4444) // Coral red
