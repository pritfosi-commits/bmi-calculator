package com.example.ui

import androidx.lifecycle.ViewModel
import com.example.model.BmiCategory
import com.example.model.BmiCalculationResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale

data class BmiUiState(
    val weightInput: String = "",
    val heightInput: String = "",
    val result: BmiCalculationResult? = null,
    val weightError: String? = null,
    val heightError: String? = null,
    val generalError: String? = null
)

class BmiViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(BmiUiState())
    val uiState: StateFlow<BmiUiState> = _uiState.asStateFlow()

    fun onWeightChange(input: String) {
        // Allow digits and at most one decimal point
        val sanitized = input.replace(',', '.')
        if (sanitized.isEmpty() || sanitized.matches(Regex("""^\d*(\.\d{0,2})?$"""))) {
            _uiState.update {
                it.copy(
                    weightInput = sanitized,
                    weightError = null,
                    generalError = null
                )
            }
        }
    }

    fun onHeightChange(input: String) {
        val sanitized = input.replace(',', '.')
        if (sanitized.isEmpty() || sanitized.matches(Regex("""^\d*(\.\d{0,2})?$"""))) {
            _uiState.update {
                it.copy(
                    heightInput = sanitized,
                    heightError = null,
                    generalError = null
                )
            }
        }
    }

    fun adjustWeight(delta: Double) {
        val current = _uiState.value.weightInput.toDoubleOrNull() ?: 70.0
        val next = (current + delta).coerceIn(10.0, 300.0)
        _uiState.update {
            it.copy(
                weightInput = if (next % 1.0 == 0.0) next.toInt().toString() else String.format(Locale.US, "%.1f", next),
                weightError = null
            )
        }
    }

    fun adjustHeight(delta: Double) {
        val current = _uiState.value.heightInput.toDoubleOrNull() ?: 170.0
        val next = (current + delta).coerceIn(50.0, 260.0)
        _uiState.update {
            it.copy(
                heightInput = if (next % 1.0 == 0.0) next.toInt().toString() else String.format(Locale.US, "%.1f", next),
                heightError = null
            )
        }
    }

    fun calculateBmi() {
        val state = _uiState.value
        val weight = state.weightInput.toDoubleOrNull()
        val height = state.heightInput.toDoubleOrNull()

        var hasError = false
        var weightErr: String? = null
        var heightErr: String? = null

        if (weight == null || weight <= 0.0) {
            weightErr = "Please enter a valid weight in kg"
            hasError = true
        } else if (weight < 10.0 || weight > 400.0) {
            weightErr = "Weight must be between 10 kg and 400 kg"
            hasError = true
        }

        if (height == null || height <= 0.0) {
            heightErr = "Please enter a valid height in cm"
            hasError = true
        } else if (height < 50.0 || height > 280.0) {
            heightErr = "Height must be between 50 cm and 280 cm"
            hasError = true
        }

        if (hasError) {
            _uiState.update {
                it.copy(
                    weightError = weightErr,
                    heightError = heightErr,
                    generalError = "Please check your inputs."
                )
            }
            return
        }

        val heightM = height!! / 100.0
        val bmi = weight!! / (heightM * heightM)
        val category = BmiCategory.fromBmi(bmi)
        val minHealthyWeight = 18.5 * (heightM * heightM)
        val maxHealthyWeight = 24.9 * (heightM * heightM)

        val calculationResult = BmiCalculationResult(
            bmi = bmi,
            category = category,
            heightCm = height,
            weightKg = weight,
            healthyWeightMinKg = minHealthyWeight,
            healthyWeightMaxKg = maxHealthyWeight
        )

        _uiState.update {
            it.copy(
                result = calculationResult,
                weightError = null,
                heightError = null,
                generalError = null
            )
        }
    }

    fun reset() {
        _uiState.update { BmiUiState() }
    }
}
