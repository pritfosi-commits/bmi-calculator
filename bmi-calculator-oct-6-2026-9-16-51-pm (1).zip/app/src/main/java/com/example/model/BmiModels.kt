package com.example.model

enum class BmiCategory(
    val title: String,
    val rangeText: String,
    val description: String
) {
    UNDERWEIGHT(
        title = "Underweight",
        rangeText = "< 18.5",
        description = "Your BMI suggests you are underweight. Consider consulting a healthcare provider or nutritionist for personalized guidance."
    ),
    NORMAL(
        title = "Normal weight",
        rangeText = "18.5 – 24.9",
        description = "Congratulations! Your BMI is within the healthy weight range for your height. Keep maintaining a balanced diet and regular physical activity."
    ),
    OVERWEIGHT(
        title = "Overweight",
        rangeText = "25.0 – 29.9",
        description = "Your BMI is slightly above the healthy range. Staying active and eating wholesome foods can help bring your BMI toward the ideal range."
    ),
    OBESE(
        title = "Obese",
        rangeText = "≥ 30.0",
        description = "Your BMI falls in the obese category. We encourage discussing personalized wellness, exercise, and dietary plans with a healthcare professional."
    );

    companion object {
        fun fromBmi(bmi: Double): BmiCategory {
            return when {
                bmi < 18.5 -> UNDERWEIGHT
                bmi < 25.0 -> NORMAL
                bmi < 30.0 -> OVERWEIGHT
                else -> OBESE
            }
        }
    }
}

data class BmiCalculationResult(
    val bmi: Double,
    val category: BmiCategory,
    val heightCm: Double,
    val weightKg: Double,
    val healthyWeightMinKg: Double,
    val healthyWeightMaxKg: Double
)
